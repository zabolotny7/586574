document.getElementById('exportBtn').addEventListener('click', async () => {
  const [tab] = await chrome.tabs.query({active: true, currentWindow: true});
  chrome.scripting.executeScript({
    target: {tabId: tab.id},
    func: () => {
      const exportBtn = document.querySelector('button[style*="position: fixed"]');
      if (exportBtn) exportBtn.click();
    }
  });
  window.close();
});